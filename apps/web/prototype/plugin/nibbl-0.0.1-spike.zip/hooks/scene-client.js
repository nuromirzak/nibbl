// src/scene-client.tsx
var SceneClient = (props, surface) => {
  if (surface.state === void 0) {
    surface.onPointer((event) => {
      if (event.type === "down" && (event.button ?? "left") === "left") surface.post({ pet: true });
    });
    surface.setState({ isListening: true });
  }
  const { Box, Text } = surface.elements;
  const runs = Array.isArray(props?.runs) ? props.runs : [];
  return /* @__PURE__ */ h(Box, { flexDirection: "column" }, runs.map((row) => /* @__PURE__ */ h(Box, { flexDirection: "row" }, row.map((run) => /* @__PURE__ */ h(Text, { ...run.color ? { color: run.color } : {}, ...run.backgroundColor ? { backgroundColor: run.backgroundColor } : {} }, run.text)))));
};
var scene_client_default = SceneClient;
export {
  scene_client_default as default
};
