// src/register.tsx
import { atom, read, update } from "claude-code";

// ../../packages/core/src/cells.ts
const toCellPairs = (grid) => {
  const rows = [];
  for (let y = 0; y + 1 < grid.length; y += 2) {
    rows.push(
      grid[y].map((top, x) => {
        const bottom = grid[y + 1][x];
        if (top !== null) return { glyph: "\u2580", fg: top, bg: bottom };
        if (bottom !== null) return { glyph: "\u2584", fg: bottom, bg: null };
        return { glyph: " ", fg: null, bg: null };
      })
    );
  }
  return rows;
};

// ../../packages/core/src/grid.ts
const blankGrid = (width, height) => Array.from({ length: height }, () => Array(width).fill(null));
const inBounds = (grid, x, y) => y >= 0 && y < grid.length && x >= 0 && x < grid[0].length;
const setCell = (grid, x, y, color) => {
  if (inBounds(grid, x, y)) grid[y][x] = color;
};

// ../../packages/core/src/palette.ts
const SWEETIE = [
  "#1a1c2c",
  "#5d275d",
  "#b13e53",
  "#ef7d57",
  "#ffcd75",
  "#a7f070",
  "#38b764",
  "#257179",
  "#29366f",
  "#3b5dc9",
  "#41a6f6",
  "#73eff7",
  "#f4f4f4",
  "#94b0c2",
  "#566c86",
  "#333c57"
];
const SWEETIE_RGB = SWEETIE.map(
  (hex) => [1, 3, 5].map((o) => Number.parseInt(hex.slice(o, o + 2), 16))
);
const C = {
  ink: 0,
  plum: 1,
  red: 2,
  orange: 3,
  yellow: 4,
  lime: 5,
  green: 6,
  teal: 7,
  navy: 8,
  blue: 9,
  sky: 10,
  cyan: 11,
  white: 12,
  silver: 13,
  slate: 14,
  dusk: 15
};
const RAMPS = {
  ember: [C.red, C.orange, C.yellow],
  moss: [C.teal, C.green, C.lime],
  ocean: [C.navy, C.blue, C.sky],
  frost: [C.blue, C.sky, C.cyan],
  ghost: [C.slate, C.silver, C.white],
  jam: [C.plum, C.red, C.orange],
  gold: [C.orange, C.yellow, C.white],
  aurora: [C.navy, C.teal, C.cyan]
};
const SHINY_RAMPS = {
  ember: [C.plum, C.orange, C.yellow],
  moss: [C.teal, C.cyan, C.white],
  ocean: [C.dusk, C.blue, C.cyan],
  frost: [C.slate, C.cyan, C.white],
  ghost: [C.plum, C.silver, C.white],
  jam: [C.plum, C.red, C.yellow],
  gold: [C.red, C.yellow, C.white],
  aurora: [C.navy, C.green, C.lime]
};

// ../../packages/core/src/prng.ts
const mulberry32 = (seed) => {
  let a = seed >>> 0;
  return () => {
    a = a + 1831565813 >>> 0;
    let t = a;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return (t ^ t >>> 14) >>> 0;
  };
};
const pickIndex = (rng, n) => rng() % n;

// ../../packages/core/src/draw.ts
const PET_SIZE = 16;
const SHRINK = { baby: 2, teen: 1, adult: 0 };
const EAR_SHAPES = {
  round: [[-3, -1], [-4, -1], [-3, -2], [-4, -2]],
  pointy: [[-3, -1], [-4, -1], [-4, -2], [-4, -3]],
  bunny: [[-3, -1], [-3, -2], [-3, -3], [-3, -4], [-4, -2], [-4, -3]],
  horns: [[-3, -1], [-4, -2], [-4, -3]]
};
const LEAF = [[7, -1], [8, -1], [8, -2], [9, -3], [10, -3], [6, -3]];
const MARK_SHAPES = {
  dot: [[0, 0]],
  star: [[0, 0], [1, 1]],
  heart: [[0, 0], [1, 0], [0, 1]],
  scar: [[0, 0], [1, 0], [2, 0]],
  sparkle: [[0, 0], [0, 1]],
  swirl: [[0, 0], [1, 0], [1, 1]]
};
const MARK_COLORS = {
  dot: [C.plum, C.navy, C.dusk, C.teal],
  star: [C.yellow, C.white, C.cyan, C.orange],
  heart: [C.red, C.plum, C.orange, C.yellow],
  scar: [C.white, C.silver, C.cyan, C.yellow],
  sparkle: [C.cyan, C.white, C.sky, C.yellow],
  swirl: [C.teal, C.lime, C.green, C.sky]
};
const markAnchor = (spot, ey, inset, canHold) => {
  if (spot === "left-cheek") return { x: 4 + inset, y: ey + 2, sx: -1, sy: 1 };
  if (spot === "right-cheek") return { x: 11 - inset, y: ey + 2, sx: 1, sy: 1 };
  if (spot === "forehead") return { x: 7, y: [ey - 1, ey].find((row) => canHold(7, row)) ?? ey - 1, sx: 1, sy: -1 };
  const y = [ey + 5, ey + 4, ey + 3].find((row) => canHold(7, row)) ?? ey + 5;
  return { x: 7, y, sx: 1, sy: 1 };
};
const PATTERN_SALT = 2654435769;
const PLACE_ATTEMPTS = 8;
const SHINY_SPARKLE = [[14, 1, C.white], [15, 0, C.cyan]];
const halves = (g, stage) => ({
  w: Math.max(3, g.halfW - SHRINK[stage]),
  h: Math.max(3, g.halfH - SHRINK[stage])
});
const insideBody = (g, w, h2, x, y) => {
  const dx2 = 2 * x - 15;
  const dy2 = 2 * y - 18;
  const ellipse = dx2 * dx2 * h2 * h2 + dy2 * dy2 * w * w <= 4 * w * w * h2 * h2;
  if (g.family === "mochi") return ellipse || y >= 9 && y <= 9 + h2 - 1 && Math.abs(dx2) * 25 <= 46 * w;
  if (g.family === "critter") return ellipse || y === 9 + h2 && (Math.abs(dx2) === 5 || Math.abs(dx2) === 7);
  const m5 = 5 * Math.max(0, 9 - y);
  const k = 8 * h2 + m5;
  return dx2 * dx2 * k * k + 64 * w * w * dy2 * dy2 <= 256 * w * w * h2 * h2;
};
const buildMask = (g, stage) => {
  const { w, h: h2 } = halves(g, stage);
  const mask = Array.from({ length: PET_SIZE }, () => Array(PET_SIZE).fill("none"));
  for (let y = 1; y < PET_SIZE; y++) {
    for (let x = 0; x < PET_SIZE; x++) if (insideBody(g, w, h2, x, y)) mask[y][x] = "body";
  }
  const top = bodyTop(mask);
  const put = (x, y, cell) => {
    if (y >= 0 && y < PET_SIZE && x >= 0 && x < PET_SIZE && mask[y][x] === "none") mask[y][x] = cell;
  };
  if (g.head === "leaf") {
    if (g.hat === "none") for (const [x, dy] of LEAF) put(x, top + dy, "leaf");
  } else if (g.head !== "none") {
    for (const [ox, oy] of EAR_SHAPES[g.head]) {
      for (const x of [8 + ox, 7 - ox]) put(x, top + 1 + oy, g.head === "horns" ? "horn" : "body");
    }
  }
  return mask;
};
const bodyTop = (mask) => {
  const y = mask.findIndex((row) => row.includes("body"));
  return y < 0 ? 0 : y;
};
const bodyRows = (mask) => {
  let top = PET_SIZE;
  let bot = 0;
  for (let y = 0; y < PET_SIZE; y++) {
    if (!mask[y].includes("body")) continue;
    if (y < top) top = y;
    bot = y;
  }
  return { top: Math.min(top, bot), bot };
};
const drawPet = (g, stage, expression) => {
  const [shade, base, hi] = (g.shiny ? SHINY_RAMPS : RAMPS)[g.ramp];
  const mask = buildMask(g, stage);
  const isBody = (x, y) => y >= 0 && y < PET_SIZE && x >= 0 && x < PET_SIZE && mask[y][x] === "body";
  const px = blankGrid(PET_SIZE, PET_SIZE);
  for (let y = 0; y < PET_SIZE; y++) {
    for (let x = 0; x < PET_SIZE; x++) {
      const cell = mask[y][x];
      if (cell === "leaf") px[y][x] = C.green;
      else if (cell === "horn") px[y][x] = C.yellow;
      else if (cell === "body") {
        const topLeft = !isBody(x - 1, y) || !isBody(x, y - 1);
        const bottomRight = !isBody(x + 1, y) || !isBody(x, y + 1);
        px[y][x] = topLeft && !bottomRight ? hi : bottomRight && !topLeft ? shade : base;
      }
    }
  }
  const { top, bot } = bodyRows(mask);
  const ey = Math.max(1, (top + bot >> 1) - 1);
  const isFace = (x, y) => y >= ey - 1 && y <= ey + 3 && x >= 3 && x <= 12;
  const paintBody = (x, y, color) => {
    if (isBody(x, y) && !isFace(x, y)) px[y][x] = color;
  };
  const rng = mulberry32(PATTERN_SALT + g.patternVariant >>> 0);
  if (g.belly) {
    for (let y = ey + 4; y < bot; y++) {
      for (let x = 5; x <= 10; x++) {
        const corner = y === bot - 1 && (x === 5 || x === 10);
        if (!corner) paintBody(x, y, hi);
      }
    }
  }
  const inset = stage === "baby" ? 1 : 0;
  const eyeColumns = [5 + inset, 10 - inset];
  const inEyeZone = (x, y) => eyeColumns.some((sx) => y === ey && (x === sx || x === sx + (sx < 8 ? -1 : 1)) || y === ey + 1 && Math.abs(x - sx) <= 1);
  const anchor = markAnchor(g.mark.spot, ey, inset, (x, y) => isBody(x, y) && !inEyeZone(x, y));
  const markPixels = MARK_SHAPES[g.mark.motif].map(([dx, dy]) => [anchor.x + dx * anchor.sx, anchor.y + dy * anchor.sy]).filter(([x, y]) => isBody(x, y) && !inEyeZone(x, y));
  const underMark = (x, y) => markPixels.some(([mx, my]) => mx === x && my === y);
  const span = Math.max(1, bot - top - 3);
  const free = (x, y) => isBody(x, y) && !isFace(x, y) && !underMark(x, y) && px[y][x] !== shade;
  const place = (fits) => {
    for (let attempt = 0; attempt < PLACE_ATTEMPTS; attempt++) {
      const x = 3 + rng() % 10;
      const y = top + 2 + rng() % span;
      if (fits(x, y)) return [x, y];
    }
    return null;
  };
  if (g.pattern === "spots") {
    const fits = (x, y) => free(x, y) && free(x + 1, y);
    let landed = 0;
    for (let i = 0; i < 4; i++) {
      const at = place(fits);
      if (at === null) continue;
      px[at[1]][at[0]] = shade;
      px[at[1]][at[0] + 1] = shade;
      landed++;
    }
    for (let y = bot; landed === 0 && y >= top; y--) {
      for (let x = 3; x <= 11 && landed === 0; x++) {
        if (!fits(x, y)) continue;
        px[y][x] = shade;
        px[y][x + 1] = shade;
        landed++;
      }
    }
  } else if (g.pattern === "stripes") {
    const v = g.patternVariant;
    for (let y = top + 1 + (v & 1); y < ey - 1; y += 2) {
      for (let x = 6 - (v >> 1 & 1); x <= 9 + (v >> 2 & 1); x++) paintBody(x, y, shade);
    }
  } else if (g.pattern === "stars" || g.pattern === "constellation") {
    const count = g.pattern === "stars" ? 3 : 5;
    const star = g.ramp === "ember" || g.ramp === "gold" ? C.white : C.yellow;
    for (let i = 0; i < count; i++) {
      const color = g.pattern === "constellation" && i % 2 === 1 ? C.white : star;
      const at = place(free);
      if (at !== null) px[at[1]][at[0]] = color;
    }
  }
  const face = (x, y, color) => setCell(px, x, y, color);
  for (const sx of eyeColumns) {
    const out = sx < 8 ? -1 : 1;
    if (expression === "blink" || expression === "sleep") {
      face(sx, ey + 1, C.ink);
      face(sx + out, ey + 1, C.ink);
    } else if (expression === "happy") {
      face(sx, ey, C.ink);
      face(sx - 1, ey + 1, C.ink);
      face(sx + 1, ey + 1, C.ink);
    } else if (expression === "sad") {
      face(sx, ey + 1, C.ink);
      face(sx + out, ey, C.ink);
    } else if (expression === "surprised") {
      face(sx, ey, C.ink);
      face(sx, ey + 1, C.ink);
    } else if (g.eyes === "dot") {
      face(sx, ey, C.ink);
    } else if (g.eyes === "big" || g.eyes === "glint") {
      face(sx, ey, g.eyes === "glint" ? C.yellow : C.white);
      face(sx, ey + 1, C.ink);
      face(sx + out, ey, C.ink);
      face(sx + out, ey + 1, C.ink);
    } else if (g.eyes === "wide") {
      face(sx, ey, C.white);
      face(sx, ey + 1, C.ink);
    } else if (g.eyes === "sleepy") {
      face(sx, ey + 1, C.ink);
      face(sx + out, ey + 1, C.ink);
    } else {
      face(sx, ey, C.red);
      face(sx + out, ey, C.red);
      face(sx, ey + 1, C.red);
    }
  }
  if (g.pattern === "freckles") {
    face(4 + inset, ey + 1, shade);
    face(11 - inset, ey + 1, shade);
  }
  if (g.blush) {
    const blush = g.ramp === "jam" ? C.plum : C.red;
    face(4 + inset, ey + 2, blush);
    face(11 - inset, ey + 2, blush);
  }
  const markColor = MARK_COLORS[g.mark.motif].find((c) => c !== shade && c !== base && c !== hi);
  for (const [x, y] of markPixels) px[y][x] = markColor;
  if (expression === "happy") {
    face(6, ey + 2, C.ink);
    face(9, ey + 2, C.ink);
    face(7, ey + 3, C.ink);
    face(8, ey + 3, C.ink);
  } else if (expression === "sad") {
    face(7, ey + 2, C.ink);
    face(8, ey + 2, C.ink);
    face(6, ey + 3, C.ink);
    face(9, ey + 3, C.ink);
  } else if (expression === "surprised") {
    face(7, ey + 2, C.ink);
    face(8, ey + 2, C.ink);
    face(7, ey + 3, C.ink);
    face(8, ey + 3, C.ink);
  } else {
    face(7, ey + 2, C.ink);
    face(8, ey + 2, C.ink);
  }
  if (g.hat === "bow") {
    for (const [x, y] of [[9, top - 1], [10, top - 1], [11, top - 1], [9, top - 2], [11, top - 2]]) {
      setCell(px, x, y, C.red);
    }
  } else if (g.hat === "crown") {
    for (let x = 5; x <= 10; x++) setCell(px, x, top - 1, C.yellow);
    for (const x of [5, 7, 8, 10]) setCell(px, x, top - 2, C.yellow);
  }
  const outlined = px.map((row) => [...row]);
  for (let y = 0; y < PET_SIZE; y++) {
    for (let x = 0; x < PET_SIZE; x++) {
      if (px[y][x] !== null) continue;
      const touches = [[-1, 0], [1, 0], [0, -1], [0, 1]].some(
        ([dx, dy]) => inBounds(px, x + dx, y + dy) && px[y + dy][x + dx] !== null
      );
      if (touches) outlined[y][x] = C.ink;
    }
  }
  if (g.shiny) for (const [x, y, color] of SHINY_SPARKLE) outlined[y][x] = color;
  return outlined;
};

// ../../packages/core/src/scene.ts
const SCENE_W = 32;
const SCENE_H = 16;
const GROUND = SCENE_H - 1;
const clamp = (v, min, max) => Number.isFinite(v) ? Math.min(max, Math.max(min, Math.trunc(v))) : min;
const BUG = [
  [0, 0, C.lime],
  [4, 0, C.lime],
  [2, 0, C.ink],
  [1, 1, C.lime],
  [2, 1, C.lime],
  [3, 1, C.lime]
];
const HEART = [
  [1, 0],
  [3, 0],
  [0, 1],
  [1, 1],
  [2, 1],
  [3, 1],
  [4, 1],
  [1, 2],
  [2, 2],
  [3, 2],
  [2, 3]
];
const drawGround = (scene) => {
  for (let x = 0; x < SCENE_W; x++) scene[GROUND][x] = x % 2 === 0 ? C.slate : C.dusk;
};
const drawScene = (g, opts = {}) => {
  const scene = blankGrid(SCENE_W, SCENE_H);
  drawGround(scene);
  const petX2 = clamp(opts.petX ?? 6, 0, SCENE_W - PET_SIZE);
  const lift = clamp(opts.lift ?? 0, 0, 3);
  const frame2 = clamp(opts.frame ?? 0, 0, 1e6);
  for (let x = petX2 + 4; x <= petX2 + 11; x++) setCell(scene, x, GROUND - 1, C.dusk);
  const pet2 = drawPet(g, opts.stage ?? "adult", opts.expression ?? "idle");
  for (let y = 0; y < PET_SIZE; y++) {
    const sy = y - lift;
    if (sy < 0 || sy >= GROUND) continue;
    for (let x = 0; x < PET_SIZE; x++) {
      const cell = pet2[y][x];
      if (cell !== null) scene[sy][petX2 + x] = cell;
    }
  }
  const bugs2 = clamp(opts.bugs ?? 0, 0, 3);
  for (let i = 0; i < bugs2; i++) {
    const bx = SCENE_W - 6 - i * 6;
    for (const [dx, dy, color] of BUG) setCell(scene, bx + dx, GROUND - 2 + dy, color);
  }
  if (opts.heart) for (const [dx, dy] of HEART) setCell(scene, SCENE_W - 8 + dx, 2 + dy, C.red);
  if (g.tier === "legendary") {
    const on = frame2 % 2 === 0;
    setCell(scene, petX2 + 1, on ? 2 : 5, C.yellow);
    setCell(scene, petX2 + 14, on ? 5 : 2, C.white);
  }
  if (g.shiny) {
    const [x, y] = frame2 % 2 === 0 ? [petX2 + 15, 2] : [petX2 + 13, 0];
    if (scene[y][x] === null) scene[y][x] = C.white;
  }
  return scene;
};

// ../../packages/core/src/egg.ts
const CRACKS = [
  [],
  [[7, 4], [8, 5], [7, 6]],
  [[7, 4], [8, 5], [7, 6], [9, 7], [10, 8], [9, 9]],
  [[7, 4], [8, 5], [7, 6], [9, 7], [10, 8], [9, 9], [5, 8], [6, 9], [5, 10]]
];
const insideEgg = (x, y) => {
  const dx2 = 2 * x - 15;
  const dy2 = 2 * y - 17;
  return dx2 * dx2 * 36 + dy2 * dy2 * 25 <= 3600;
};
const drawEgg = (cracks) => {
  const egg = blankGrid(PET_SIZE, PET_SIZE);
  for (let y = 0; y < PET_SIZE; y++) {
    for (let x = 0; x < PET_SIZE; x++) {
      if (!insideEgg(x, y)) continue;
      const bottomRight = !insideEgg(x + 1, y) || !insideEgg(x, y + 1);
      egg[y][x] = bottomRight ? C.silver : C.white;
    }
  }
  for (const [x, y] of [[6, 6], [9, 10], [5, 11]]) setCell(egg, x, y, C.sky);
  for (const [x, y] of CRACKS[cracks]) setCell(egg, x, y, C.ink);
  const outlined = egg.map((row) => [...row]);
  for (let y = 0; y < PET_SIZE; y++) {
    for (let x = 0; x < PET_SIZE; x++) {
      if (egg[y][x] !== null) continue;
      const touches = [[-1, 0], [1, 0], [0, -1], [0, 1]].some(
        ([dx, dy]) => inBounds(egg, x + dx, y + dy) && egg[y + dy][x + dx] !== null
      );
      if (touches) outlined[y][x] = C.ink;
    }
  }
  return outlined;
};
const drawEggScene = (cracks, frame2 = 0) => {
  const scene = blankGrid(SCENE_W, SCENE_H);
  drawGround(scene);
  const wobble = cracks > 0 && frame2 % 2 === 1 ? 1 : 0;
  const egg = drawEgg(cracks);
  for (let y = 0; y < PET_SIZE - 1; y++) {
    for (let x = 0; x < PET_SIZE; x++) {
      const cell = egg[y][x];
      if (cell !== null) setCell(scene, 8 + x + wobble, y, cell);
    }
  }
  return scene;
};

// ../../packages/core/src/genes.ts
const opt = (value, weight, minTier = "common") => ({ value, weight, minTier });
const POOLS = {
  family: [opt("mochi", 40), opt("critter", 40), opt("sprout", 20)],
  halfW: [opt(5, 1), opt(6, 2), opt(7, 1)],
  halfH: [opt(5, 1), opt(6, 2), opt(7, 1)],
  ramp: [
    opt("ember", 30),
    opt("moss", 30),
    opt("ocean", 30),
    opt("frost", 20, "uncommon"),
    opt("ghost", 20, "uncommon"),
    opt("jam", 20, "rare"),
    opt("gold", 10, "epic"),
    opt("aurora", 10, "legendary")
  ],
  pattern: [
    opt("none", 60),
    opt("spots", 40),
    opt("freckles", 4),
    opt("stripes", 30, "uncommon"),
    opt("stars", 20, "rare"),
    opt("constellation", 10, "epic")
  ],
  belly: [opt(true, 60), opt(false, 40)],
  eyes: [
    opt("dot", 40),
    opt("big", 40),
    opt("wide", 30),
    opt("heart", 4),
    opt("sleepy", 20, "uncommon"),
    opt("glint", 10, "rare")
  ],
  blush: [opt(true, 50), opt(false, 50)],
  head: [
    opt("none", 30),
    opt("round", 30),
    opt("pointy", 30),
    opt("bunny", 20, "uncommon"),
    opt("horns", 10, "rare")
  ]
};
const HAT_BY_TIER = {
  common: "none",
  uncommon: "none",
  rare: "none",
  epic: "bow",
  legendary: "crown"
};
const MARK_MOTIFS = ["dot", "star", "heart", "scar", "sparkle", "swirl"];
const MARK_SPOTS = ["left-cheek", "right-cheek", "forehead", "belly"];

// ../../packages/core/src/odds.ts
const TIERS = ["common", "uncommon", "rare", "epic", "legendary"];
const BP = 1e4;
const TIER_BP = { common: 4e3, uncommon: 3e3, rare: 1800, epic: 900, legendary: 300 };
const SHINY_BP = 400;
const toBp = (roll) => {
  if (!Number.isFinite(roll)) throw new RangeError(`roll must be finite, got ${roll}`);
  return (roll % BP + BP) % BP;
};
const isTier = (x) => typeof x === "string" && TIERS.includes(x);
const tierRank = (t) => TIERS.indexOf(t);
const tierFromRoll = (roll) => {
  let r = toBp(roll);
  for (const t of TIERS) {
    if (r < TIER_BP[t]) return t;
    r -= TIER_BP[t];
  }
  return "legendary";
};
const shinyFromRoll = (roll) => toBp(roll) < SHINY_BP;
const tierProbability = (t) => TIER_BP[t] / BP;
const uint32At = (bytes, offset) => (bytes[offset] << 24 | bytes[offset + 1] << 16 | bytes[offset + 2] << 8 | bytes[offset + 3]) >>> 0;
const rollFromBytes = (bytes) => {
  if (bytes.length < 12) throw new RangeError(`rollFromBytes needs at least 12 bytes, got ${bytes.length}`);
  return { seed: uint32At(bytes, 0), tier: tierFromRoll(uint32At(bytes, 4)), shiny: shinyFromRoll(uint32At(bytes, 8)) };
};

// ../../packages/core/src/genome.ts
const PATTERN_VARIANTS = 16;
const SHINY_PROBABILITY = SHINY_BP / BP;
const MARK_PROBABILITY = 1 / (MARK_MOTIFS.length * MARK_SPOTS.length);
const eligible = (pool, tier) => pool.filter((o) => tierRank(o.minTier) <= tierRank(tier));
const pick = (rng, pool, tier) => {
  const options = eligible(pool, tier);
  const total = options.reduce((s, o) => s + o.weight, 0);
  let r = pickIndex(rng, total);
  for (const o of options) {
    if (r < o.weight) return o.value;
    r -= o.weight;
  }
  return options[options.length - 1].value;
};
const conditional = (pool, tier, value) => {
  const options = eligible(pool, tier);
  const match = options.find((o) => o.value === value);
  return match ? match.weight / options.reduce((s, o) => s + o.weight, 0) : 0;
};
const table = (values, given) => new Map(values.map((v) => [v, TIERS.reduce((sum, t) => sum + tierProbability(t) * given(t, v), 0)]));
const poolTable = (pool) => table(pool.map((o) => String(o.value)), (t, v) => conditional(pool, t, pool.find((o) => String(o.value) === v).value));
const sproutGiven = (t) => conditional(POOLS.family, t, "sprout");
const ODDS = {
  family: poolTable(POOLS.family),
  ramp: poolTable(POOLS.ramp),
  pattern: poolTable(POOLS.pattern),
  eyes: poolTable(POOLS.eyes),
  head: table([...POOLS.head.map((o) => o.value), "leaf"], (t, v) => {
    if (v === "leaf") return sproutGiven(t);
    const head = HAT_BY_TIER[t] === "none" ? conditional(POOLS.head, t, v) : v === "none" ? 1 : 0;
    return (1 - sproutGiven(t)) * head;
  }),
  hat: table([...new Set(Object.values(HAT_BY_TIER))], (t, v) => HAT_BY_TIER[t] === v ? 1 : 0)
};
const markLabel = (m) => `${m.motif} on ${m.spot.replace("-", " ")}`;
const traitOdds = (g) => {
  const of = (gene, value) => ({ gene, value, probability: ODDS[gene].get(value) ?? 0 });
  const odds = [
    of("family", g.family),
    of("ramp", g.ramp),
    of("pattern", g.pattern),
    of("eyes", g.eyes),
    of("head", g.head),
    of("hat", g.hat),
    { gene: "mark", value: markLabel(g.mark), probability: MARK_PROBABILITY }
  ];
  if (g.shiny) odds.push({ gene: "shiny", value: "shiny", probability: SHINY_PROBABILITY });
  return odds;
};
const rarestTrait = (g) => traitOdds(g).reduce((min, t) => t.probability < min.probability ? t : min);
const genome = (seed, tier, shiny) => {
  if (!isTier(tier)) throw new RangeError(`unknown tier: ${String(tier)}`);
  const normalized = seed >>> 0;
  const rng = mulberry32(normalized);
  const family = pick(rng, POOLS.family, tier);
  const g = {
    seed: normalized,
    tier,
    shiny,
    family,
    halfW: pick(rng, POOLS.halfW, tier),
    halfH: pick(rng, POOLS.halfH, tier),
    ramp: pick(rng, POOLS.ramp, tier),
    pattern: pick(rng, POOLS.pattern, tier),
    belly: pick(rng, POOLS.belly, tier),
    eyes: pick(rng, POOLS.eyes, tier),
    blush: pick(rng, POOLS.blush, tier),
    head: pick(rng, POOLS.head, tier),
    hat: HAT_BY_TIER[tier],
    mark: { motif: MARK_MOTIFS[pickIndex(rng, MARK_MOTIFS.length)], spot: MARK_SPOTS[pickIndex(rng, MARK_SPOTS.length)] },
    patternVariant: pickIndex(rng, PATTERN_VARIANTS)
  };
  if (family === "sprout") g.head = "leaf";
  if (g.hat !== "none" && family !== "sprout") g.head = "none";
  return g;
};

// ../../packages/core/src/progression.ts
const HOUR_MS = 36e5;
const SYNC_GRACE_MS = 3 * HOUR_MS;
const FIRST_SYNC_LOOKBACK_MS = 24 * HOUR_MS;
const MAX_LEVEL = 99;
const XP_PER_EVENT = { pet: 2, turn: 3, check_pass: 2, commit: 2, error: 0 };
const CAPS_PER_HOUR = { pet: 5, turn: 20, check_pass: 20, commit: 10 };
const hourOf = (at) => Math.floor(at / HOUR_MS);
const isEventType = (t) => typeof t === "string" && Object.prototype.hasOwnProperty.call(XP_PER_EVENT, t);
const scoreEvents = (events, windows2, now, lastSyncAt) => {
  if (!Array.isArray(events) || !Number.isFinite(now) || lastSyncAt !== null && !Number.isFinite(lastSyncAt)) {
    return { xpGained: 0, windows: Object.fromEntries(Object.entries(windows2).map(([h2, w]) => [h2, { ...w }])), accepted: 0 };
  }
  const oldest = lastSyncAt === null ? now - FIRST_SYNC_LOOKBACK_MS : lastSyncAt - SYNC_GRACE_MS;
  const next = Object.fromEntries(Object.entries(windows2).map(([h2, w]) => [h2, { ...w }]));
  let xpGained = 0;
  let accepted = 0;
  for (const e of events) {
    if (!e || typeof e !== "object") continue;
    if (!isEventType(e.type) || !Number.isFinite(e.at) || e.at > now || e.at < oldest) continue;
    if (e.type === "error") continue;
    const hour = hourOf(e.at);
    const window = next[hour] ??= {};
    const used = window[e.type] ?? 0;
    if (used >= CAPS_PER_HOUR[e.type]) continue;
    window[e.type] = used + 1;
    xpGained += XP_PER_EVENT[e.type];
    accepted++;
  }
  return { xpGained, windows: next, accepted };
};
const pruneWindows = (windows2, now) => {
  const oldest = Number.isFinite(now) ? Math.floor((now - SYNC_GRACE_MS) / HOUR_MS) : -Infinity;
  return Object.fromEntries(
    Object.entries(windows2).filter(([h2]) => Number(h2) >= oldest).map(([h2, w]) => [h2, { ...w }])
  );
};
const heartsLeft = (windows2, now) => Math.max(0, CAPS_PER_HOUR.pet - (windows2[hourOf(now)]?.pet ?? 0));
const xpToNext = (level) => Math.round(10 * level ** 1.4);
const levelFromXp = (xp) => {
  const safe = Number.isFinite(xp) ? Math.max(0, Math.floor(xp)) : 0;
  let level = 1;
  let rest = safe;
  while (rest >= xpToNext(level) && level < MAX_LEVEL) {
    rest -= xpToNext(level);
    level++;
  }
  return { level, intoLevel: rest, toNext: xpToNext(level) };
};
const stageForLevel = (level) => level >= 25 ? "adult" : level >= 10 ? "teen" : "baby";

// src/cells.ts
const TERMINAL_DEFAULT = 16777216;
const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
const toBase64 = (bytes) => {
  let out = "";
  let i = 0;
  for (; i + 2 < bytes.length; i += 3) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
    out += B64[n >> 18 & 63] + B64[n >> 12 & 63] + B64[n >> 6 & 63] + B64[n & 63];
  }
  const rest = bytes.length - i;
  if (rest === 1) {
    const n = bytes[i] << 16;
    out += B64[n >> 18 & 63] + B64[n >> 12 & 63] + "==";
  } else if (rest === 2) {
    const n = bytes[i] << 16 | bytes[i + 1] << 8;
    out += B64[n >> 18 & 63] + B64[n >> 12 & 63] + B64[n >> 6 & 63] + "=";
  }
  return out;
};
const rgbOf = (index) => {
  if (index === null) return TERMINAL_DEFAULT;
  const rgb = SWEETIE_RGB[index];
  return rgb ? rgb[0] << 16 | rgb[1] << 8 | rgb[2] : TERMINAL_DEFAULT;
};
const writeU32 = (out, offset, v) => {
  out[offset] = v & 255;
  out[offset + 1] = v >>> 8 & 255;
  out[offset + 2] = v >>> 16 & 255;
  out[offset + 3] = v >>> 24 & 255;
};
const encodeRaster = (pairs) => {
  const rows = pairs.length;
  const columns = pairs[0]?.length ?? 0;
  const out = new Uint8Array(rows * columns * 12);
  let o = 0;
  for (const row of pairs) {
    for (const cell of row) {
      writeU32(out, o, cell.glyph.codePointAt(0) ?? 32);
      writeU32(out, o + 4, rgbOf(cell.fg));
      writeU32(out, o + 8, rgbOf(cell.bg));
      o += 12;
    }
  }
  return { columns, rows, cells: toBase64(out) };
};
const hexOf = (index) => index === null ? void 0 : SWEETIE[index];
const toRuns = (pairs) => pairs.map((row) => {
  const runs = [];
  for (const cell of row) {
    const color = cell.glyph === " " ? void 0 : hexOf(cell.fg);
    const backgroundColor = hexOf(cell.bg);
    const last = runs[runs.length - 1];
    if (last && last.backgroundColor === backgroundColor && (cell.glyph === " " || last.color === color)) {
      last.text += cell.glyph;
      if (last.color === void 0 && color !== void 0) last.color = color;
      continue;
    }
    const run = { text: cell.glyph };
    if (color !== void 0) run.color = color;
    if (backgroundColor !== void 0) run.backgroundColor = backgroundColor;
    runs.push(run);
  }
  return runs;
});
const drawingOf = (grid) => {
  const pairs = toCellPairs(grid);
  return { raster: encodeRaster(pairs), runs: toRuns(pairs) };
};

// src/logic.ts
const HATCH_AFTER_TURNS = 3;
const HATCH_DELAY_MS = 1500;
const TICK_MS = 500;
const MOOD_MS = 6e3;
const HEART_MS = 2e3;
const SLEEP_AFTER_MS = 3 * 60 * 1e3;
const MAX_BUGS = 3;
const MAX_NAME = 16;
const MIN_FULL_ROWS = 8;
const WALK_MAX_X = 16;
const DEFAULT_X = 8;
const CHECK_COMMAND = /\b(test|vitest|jest|pytest|tsc|lint|build)\b/;
const COMMIT_COMMAND = /\bgit\s+commit\b/;
const pickLook = (s) => {
  if (s.mood !== "idle" && s.now < s.moodUntil) return s.mood === "sad" ? "oops" : "yay";
  if (s.isWorking) return "working";
  if (s.lastActiveAt > 0 && s.now - s.lastActiveAt > SLEEP_AFTER_MS) return "zzz";
  return "chilling";
};
const expressionFor = (look, blink2, heart) => {
  if (look === "oops") return "sad";
  if (look === "yay" || heart) return "happy";
  if (look === "zzz") return "sleep";
  return blink2 ? "blink" : "idle";
};
const liftFor = (look, frame2) => {
  if (look === "zzz") return 0;
  if (look === "working") return frame2 % 2;
  return Math.floor(frame2 / 2) % 2;
};
const xpBar = (into, toNext, width = 5) => {
  const filled = toNext > 0 ? Math.min(width, Math.round(width * into / toNext)) : 0;
  return "\u2593".repeat(filled) + "\u2591".repeat(width - filled);
};
const heartsBar = (left, max = 5) => "\u2665".repeat(left) + "\u2661".repeat(Math.max(0, max - left));
const pct = (p) => {
  const v = p * 100;
  return v >= 10 ? v.toFixed(0) : v >= 1 ? v.toFixed(1) : v.toFixed(2);
};
const spikeHatchBytes = (now, rand = Math.random) => {
  const out = new Uint8Array(12);
  let mix = (now >>> 0 ^ Math.floor(now / 4294967296)) >>> 0;
  for (let i = 0; i < out.length; i++) {
    out[i] = (Math.floor(rand() * 256) ^ mix >>> i % 4 * 8) & 255;
    mix = Math.imul(mix ^ out[i], 16777619) >>> 0;
  }
  return out;
};
const genomes = /* @__PURE__ */ new Map();
const genomeOf = (seed, tier, shiny) => {
  const key = `${seed}.${tier}.${shiny ? 1 : 0}`;
  let g = genomes.get(key);
  if (!g) {
    g = genome(seed, tier, shiny);
    genomes.set(key, g);
  }
  return g;
};
const rarestLine = (g) => {
  const t = rarestTrait(g);
  const label = t.gene === "mark" || t.gene === "shiny" ? t.value : `${t.value} ${t.gene}`;
  return `${label} ${pct(t.probability)}% odds`;
};
const scenes = /* @__PURE__ */ new Map();
const remember = (key, make) => {
  let d = scenes.get(key);
  if (!d) {
    if (scenes.size > 512) scenes.clear();
    d = make();
    scenes.set(key, d);
  }
  return d;
};
const petDrawing = (g, k) => remember(
  `${g.seed}.${g.tier}.${g.shiny ? 1 : 0}|${k.stage}|${k.expression}|${k.petX}|${k.lift}|${k.bugs}|${k.heart ? 1 : 0}|${k.frame % 2}`,
  () => drawingOf(drawScene(g, { ...k, frame: k.frame % 2 }))
);
const eggCracks = (turns) => Math.max(0, Math.min(3, Math.floor(turns * 3 / HATCH_AFTER_TURNS)));
const eggDrawing = (turns, frame2) => {
  const cracks = eggCracks(turns);
  return remember(`egg|${cracks}|${frame2 % 2}`, () => drawingOf(drawEggScene(cracks, frame2 % 2)));
};
const levelOf = (xp) => levelFromXp(xp);

// src/register.tsx
const loaded = atom({ plugin: "nibbl", key: "loaded" }, false);
const frame = atom({ plugin: "nibbl", key: "frame" }, 0);
const hidden = atom({ plugin: "nibbl", key: "hidden" }, false);
const working = atom({ plugin: "nibbl", key: "working" }, false);
const pet = atom({ plugin: "nibbl", key: "pet" }, null);
const eggTurns = atom({ plugin: "nibbl", key: "eggTurns" }, 0);
const mood = atom({ plugin: "nibbl", key: "mood" }, "idle");
const moodUntil = atom({ plugin: "nibbl", key: "moodUntil" }, 0);
const bugs = atom({ plugin: "nibbl", key: "bugs" }, 0);
const heartUntil = atom({ plugin: "nibbl", key: "heartUntil" }, 0);
const lastActiveAt = atom({ plugin: "nibbl", key: "lastActiveAt" }, 0);
const windows = atom({ plugin: "nibbl", key: "windows" }, {});
const petX = atom({ plugin: "nibbl", key: "petX" }, DEFAULT_X);
const dir = atom({ plugin: "nibbl", key: "dir" }, 1);
const blink = atom({ plugin: "nibbl", key: "blink" }, false);
const mode = atom({ plugin: "nibbl", key: "mode" }, "raster");
const STORE = { pet: "pet", eggTurns: "eggTurns", windows: "windows", lastScoredAt: "lastScoredAt", mode: "mode" };
const MODES = ["raster", "text", "client"];
const isPet = (v) => typeof v === "object" && v !== null && typeof v.seed === "number" && typeof v.tier === "string";
const runtime = { ticker: null, isHatching: false };
const ensureLoaded = async ($) => {
  if (await read($, loaded)) return;
  const savedPet = await $.store.get(STORE.pet);
  const savedTurns = Number(await $.store.get(STORE.eggTurns) ?? 0);
  const savedWindows = await $.store.get(STORE.windows);
  const savedMode = await $.store.get(STORE.mode);
  await update($, pet, () => isPet(savedPet) ? savedPet : null);
  await update($, eggTurns, () => Number.isFinite(savedTurns) ? savedTurns : 0);
  await update($, windows, () => savedWindows && typeof savedWindows === "object" ? savedWindows : {});
  if (MODES.includes(savedMode)) await update($, mode, () => savedMode);
  await update($, loaded, () => true);
  if (!isPet(savedPet) && savedTurns >= HATCH_AFTER_TURNS) await hatch($);
};
const markActive = async ($) => {
  const now = await $.clock.now();
  await update($, lastActiveAt, () => now);
  return now;
};
const feel = async ($, next, ms) => {
  const now = await $.clock.now();
  await update($, mood, () => next);
  await update($, moodUntil, () => now + ms);
};
const savePet = async ($, p) => {
  await update($, pet, () => p);
  if (p) await $.store.set(STORE.pet, p);
  else await $.store.delete(STORE.pet);
};
const score = async ($, type) => {
  const current = await read($, pet);
  if (!current) return 0;
  const now = await $.clock.now();
  const last = await $.store.get(STORE.lastScoredAt);
  const before = await read($, windows);
  const result = scoreEvents([{ type, at: now }], before, now, typeof last === "number" ? last : null);
  const kept = pruneWindows(result.windows, now);
  await update($, windows, () => kept);
  await $.store.set(STORE.windows, kept);
  await $.store.set(STORE.lastScoredAt, now);
  if (result.xpGained > 0) {
    const xp = current.xp + result.xpGained;
    const was = levelOf(current.xp).level;
    const is = levelOf(xp).level;
    await savePet($, { ...current, xp });
    if (is > was) $.ui.toast(`${current.name} reached level ${is}!`);
  }
  return result.accepted;
};
const hatch = async ($) => {
  if (runtime.isHatching || await read($, pet)) return;
  runtime.isHatching = true;
  try {
    const now = await $.clock.now();
    const roll = rollFromBytes(spikeHatchBytes(now));
    const born = { seed: roll.seed, tier: roll.tier, shiny: roll.shiny, hatchedAt: now, xp: 0, name: "Byte" };
    await savePet($, born);
    await $.store.delete(STORE.eggTurns);
    await update($, eggTurns, () => 0);
    $.ui.toast(`${born.name} hatched! rarest: ${rarestLine(genomeOf(born.seed, born.tier, born.shiny))}`);
  } finally {
    runtime.isHatching = false;
  }
};
const tick = async ($) => {
  await update($, frame, (n) => (n + 1) % 1e5);
  if (await read($, working)) {
    const x = await read($, petX);
    let d = await read($, dir);
    if (x + d < 0 || x + d > WALK_MAX_X) d = -d;
    await update($, dir, () => d);
    await update($, petX, () => x + d);
  }
  const isBlinking = await read($, blink);
  const shouldBlink = !isBlinking && Math.random() < 0.08;
  if (isBlinking || shouldBlink) await update($, blink, () => shouldBlink);
};
const ensureRunning = async ($) => {
  if (runtime.ticker) return;
  runtime.ticker = $.clock.every(TICK_MS, () => {
    void tick($);
  });
  await $.command.register({
    name: "nibbl",
    description: "Nibbl spike: /nibbl, /nibbl name <text>, /nibbl hide, /nibbl mode raster|text|client, /nibbl reset",
    argumentHint: "[name <text> | hide | mode <m> | reset]"
  });
};
const petPressed = async ($) => {
  await ensureLoaded($);
  const now = await markActive($);
  const current = await read($, pet);
  if (!current) {
    $.ui.toast("The egg wiggles. Keep working to hatch it.");
    return;
  }
  const accepted = await score($, "pet");
  await feel($, "happy", HEART_MS);
  if (accepted > 0) {
    await update($, heartUntil, () => now + HEART_MS);
    const left = heartsLeft(await read($, windows), now);
    $.ui.toast(`${current.name} loved that! +2 XP  ${"\u2665".repeat(left)}${"\u2661".repeat(5 - left)}`);
  } else $.ui.toast(`${current.name} is all petted out this hour.`);
};
const statsText = async ($) => {
  const current = await read($, pet);
  if (!current) {
    const turns = await read($, eggTurns);
    return `Egg: ${turns}/${HATCH_AFTER_TURNS} answered turns, hatches after ${HATCH_AFTER_TURNS}.`;
  }
  const g = genomeOf(current.seed, current.tier, current.shiny);
  const lv = levelOf(current.xp);
  const now = await $.clock.now();
  const left = heartsLeft(await read($, windows), now);
  const looks = traitOdds(g).map((t) => `${t.gene} ${t.value} (${pct(t.probability)}%)`).join(", ");
  return [
    `${current.name} #local \xB7 ${current.tier}${current.shiny ? " \xB7 shiny" : ""}`,
    `lvl ${lv.level}, ${current.xp} xp (${lv.intoLevel}/${lv.toNext} to next)`,
    `hearts left this hour: ${left}/5`,
    `bugs ${await read($, bugs)}`,
    `traits: ${looks}`,
    `rarest trait: ${rarestLine(g)}`,
    `seed ${current.seed >>> 0}, hatched ${new Date(current.hatchedAt).toISOString()} (spike: local random roll)`
  ].join("\n");
};
const reset = async ($) => {
  for (const key of await $.store.keys()) await $.store.delete(key);
  await update($, pet, () => null);
  await update($, eggTurns, () => 0);
  await update($, windows, () => ({}));
  await update($, bugs, () => 0);
  await update($, mood, () => "idle");
  await update($, moodUntil, () => 0);
  await update($, heartUntil, () => 0);
  await update($, petX, () => DEFAULT_X);
  await update($, hidden, () => false);
};
export const register = (on) => {
  on("session.start", async ($, e, next) => {
    await ensureLoaded($);
    await markActive($);
    await ensureRunning($);
    return next(e);
  });
  on("ui.press", { plugin: "nibbl", element: "pet" }, async ($, e, next) => {
    await petPressed($);
    return next(e);
  });
  on("command.run", { command: "nibbl" }, async ($, e) => {
    await ensureLoaded($);
    const [verb = "", ...rest] = e.args.trim().split(/\s+/);
    if (verb === "name") {
      const name = rest.join(" ").trim();
      const current = await read($, pet);
      if (!current) return { text: "Hatch the egg first, then name it." };
      if (name.length === 0 || name.length > MAX_NAME) return { text: `A name is 1 to ${MAX_NAME} characters.` };
      await savePet($, { ...current, name });
      return { text: `Renamed to ${name}.` };
    }
    if (verb === "hide") {
      const was = await read($, hidden);
      await update($, hidden, () => !was);
      return { text: was ? "Nibbl is back." : "Nibbl is hidden. /nibbl hide brings it back." };
    }
    if (verb === "mode") {
      const want = rest[0];
      if (!MODES.includes(want)) return { text: `Modes: ${MODES.join(", ")}.` };
      await update($, mode, () => want);
      await $.store.set(STORE.mode, want);
      return { text: `Scene drawn with ${want}.` };
    }
    if (verb === "reset") {
      await reset($);
      return { text: `Back to an egg. It hatches after ${HATCH_AFTER_TURNS} answered turns.` };
    }
    return { text: await statsText($) };
  });
  on("turn.start", async ($, e, next) => {
    await ensureLoaded($);
    await ensureRunning($);
    await markActive($);
    await update($, working, () => true);
    return next(e);
  });
  on("turn.complete", async ($, e, next) => {
    if (e.agentId !== void 0) return next(e);
    await ensureLoaded($);
    await markActive($);
    await update($, working, () => false);
    if (e.reason === "answer") {
      if (await read($, pet)) {
        await score($, "turn");
      } else {
        const turns = await read($, eggTurns) + 1;
        await update($, eggTurns, () => turns);
        await $.store.set(STORE.eggTurns, turns);
        if (turns >= HATCH_AFTER_TURNS) {
          $.clock.after(HATCH_DELAY_MS, () => {
            void hatch($);
          });
        }
      }
    }
    return next(e);
  });
  on("tool.call", async ($, e, next) => {
    const ran = await next(e);
    if (ran.deny !== void 0) return ran;
    await ensureLoaded($);
    await markActive($);
    const command = e.tool === "Bash" ? String(e.command ?? "") : "";
    if (ran.isError === true) {
      await update($, bugs, (n) => Math.min(MAX_BUGS, n + 1));
      await feel($, "sad", MOOD_MS);
      await score($, "error");
    } else if (command && CHECK_COMMAND.test(command)) {
      await update($, bugs, () => 0);
      await feel($, "happy", MOOD_MS);
      await score($, "check_pass");
    }
    if (ran.isError !== true && COMMIT_COMMAND.test(command)) await score($, "commit");
    return ran;
  });
  on("ui.message", async ($, e, next) => {
    const data = e.data;
    if (e.element === "scene" && data && data.pet === true) {
      await petPressed($);
      return {};
    }
    return next(e);
  });
  on("ui.render", { component: "AbovePrompt" }, async ($, e, next) => {
    if (e.props.hasSurvey || await read($, hidden)) return next(e);
    const now = await $.clock.now();
    const tickNo = await read($, frame);
    const current = await read($, pet);
    const isCompact = e.props.maxRows < MIN_FULL_ROWS;
    const ui = $.ui.resolve(e);
    const { Box, Text, Button } = ui;
    const sceneMode = await read($, mode);
    const petButton = /* @__PURE__ */ h(Button, { key: "pet", label: "\u2665", hotkey: "p", onPress: () => {
    } });
    const sceneOf = (drawing2) => {
      if (e.surface === "terminal") {
        const t = $.ui.resolve(e);
        if (sceneMode === "raster") {
          const { Raster } = t;
          return /* @__PURE__ */ h(Raster, { key: "scene", columns: drawing2.raster.columns, rows: drawing2.raster.rows, cells: drawing2.raster.cells });
        }
        if (sceneMode === "client") {
          const { Client } = t;
          return /* @__PURE__ */ h(Client, { key: "scene", module: "./scene-client.js", props: { runs: drawing2.runs }, width: drawing2.raster.columns, height: drawing2.raster.rows });
        }
      }
      return /* @__PURE__ */ h(Box, { flexDirection: "column" }, drawing2.runs.map((row) => /* @__PURE__ */ h(Box, { flexDirection: "row" }, row.map((run) => /* @__PURE__ */ h(Text, { ...run.color ? { color: run.color } : {}, ...run.backgroundColor ? { backgroundColor: run.backgroundColor } : {} }, run.text)))));
    };
    if (!current) {
      const turns = await read($, eggTurns);
      const hud = `Egg \xB7 hatches after ${HATCH_AFTER_TURNS} turns`;
      const progress = `turns ${Math.min(turns, HATCH_AFTER_TURNS)}/${HATCH_AFTER_TURNS}${turns >= HATCH_AFTER_TURNS ? " \xB7 hatching!" : ""}`;
      if (isCompact) {
        return /* @__PURE__ */ h(Box, { flexDirection: "row", width: e.props.bodyColumns }, /* @__PURE__ */ h(Text, { color: "#ffcd75" }, hud), /* @__PURE__ */ h(Text, { dimColor: true }, " \xB7 ", progress));
      }
      return /* @__PURE__ */ h(Box, { flexDirection: "row", justifyContent: "flex-end", alignItems: "center", width: e.props.bodyColumns }, /* @__PURE__ */ h(Box, { flexDirection: "column", alignItems: "flex-end", marginRight: 1 }, /* @__PURE__ */ h(Text, { color: "#ffcd75", bold: true }, hud), /* @__PURE__ */ h(Text, { dimColor: true }, progress), /* @__PURE__ */ h(Text, { dimColor: true, italic: true }, "cracks: ", eggCracks(turns), "/3")), sceneOf(eggDrawing(turns, tickNo)));
    }
    const g = genomeOf(current.seed, current.tier, current.shiny);
    const lv = levelOf(current.xp);
    const isWorking = await read($, working) || e.props.isWorking;
    const look = pickLook({
      isWorking,
      mood: await read($, mood),
      moodUntil: await read($, moodUntil),
      lastActiveAt: await read($, lastActiveAt),
      now
    });
    const heart = now < await read($, heartUntil);
    const left = heartsLeft(await read($, windows), now);
    const title = `${current.name} #local \xB7 ${current.tier}${current.shiny ? " \xB7 shiny" : ""}`;
    const xpLine = `lvl ${lv.level}  ${xpBar(lv.intoLevel, lv.toNext)} ${lv.intoLevel}/${lv.toNext}`;
    const hearts = heartsBar(left);
    if (isCompact) {
      return /* @__PURE__ */ h(Box, { flexDirection: "row", width: e.props.bodyColumns }, /* @__PURE__ */ h(Text, { color: "#ef7d57", bold: true }, current.name), /* @__PURE__ */ h(Text, { dimColor: true }, " lvl ", lv.level, " "), /* @__PURE__ */ h(Text, { color: "#b13e53" }, hearts), /* @__PURE__ */ h(Text, { dimColor: true, italic: true }, " ", look, " "), petButton);
    }
    const drawing = petDrawing(g, {
      stage: stageForLevel(lv.level),
      expression: expressionFor(look, await read($, blink), heart),
      petX: await read($, petX),
      lift: liftFor(look, tickNo),
      bugs: await read($, bugs),
      heart,
      frame: tickNo
    });
    return /* @__PURE__ */ h(Box, { flexDirection: "row", justifyContent: "flex-end", alignItems: "center", width: e.props.bodyColumns }, /* @__PURE__ */ h(Box, { flexDirection: "column", alignItems: "flex-end", marginRight: 1 }, /* @__PURE__ */ h(Text, { color: "#ef7d57", bold: true }, title), /* @__PURE__ */ h(Text, null, xpLine), /* @__PURE__ */ h(Text, { color: "#b13e53" }, hearts), /* @__PURE__ */ h(Text, { dimColor: true, italic: true }, look), petButton), sceneOf(drawing));
  });
};
